---
name: WAASHA
colors:
  surface: '#f9f9ff'
  surface-dim: '#d0daf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e8eeff'
  surface-container-high: '#dfe8ff'
  surface-container-highest: '#d9e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#44474c'
  inverse-surface: '#273143'
  inverse-on-surface: '#ecf0ff'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4e6077'
  primary: '#00050e'
  on-primary: '#ffffff'
  primary-container: '#0b1f33'
  on-primary-container: '#7587a0'
  inverse-primary: '#b5c8e3'
  secondary: '#006a60'
  on-secondary: '#ffffff'
  secondary-container: '#70f5e2'
  on-secondary-container: '#006f64'
  tertiary: '#000706'
  on-tertiary: '#ffffff'
  tertiary-container: '#122120'
  on-tertiary-container: '#798988'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b5c8e3'
  on-primary-fixed: '#081d30'
  on-primary-fixed-variant: '#36485e'
  secondary-fixed: '#74f8e5'
  secondary-fixed-dim: '#53dbc9'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#d5e6e4'
  tertiary-fixed-dim: '#b9cac8'
  on-tertiary-fixed: '#0f1e1d'
  on-tertiary-fixed-variant: '#3a4a49'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d9e3fb'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  max-width-content: 75rem
---

## Brand & Style

This design system delivers a progressive, high-trust marketplace interface that connects everyday consumers with localized grooming, personal care, and automotive detailing professionals within an exact 10 km operational perimeter. Built under the ethos "THE FUTURE OF SERVICE, TODAY," the system merges modern utility with human warmth and technical precision.

The visual direction follows a contemporary, structured, and confident aesthetic. It rejects cluttered marketplace conventions in favor of deep structural contrasts, deliberate whitespace, and tactile polish. Micro-interactions should feel instantaneous, communicative, and dependable. The emotional tone evokes calm certainty, verified competence, and frictionless neighborhood accessibility.

## Colors

The palette balances authoritative deep tones with high-energy, hygienic accents to reflect cleanliness, trust, and digital agility.

- **Primary Brand (`#0B1F33` - Deep Navy):** Anchors the interface. Applied to structural framing, primary navigation, solid CTA buttons, heavy typography, and prominent surfaces.
- **Secondary Accent (`#19B6A5` - Waasha Teal):** Represents action, accuracy, and freshness. Deployed for active tab states, hyperlinked elements, dynamic status badges, verification diamonds, and focused input indicators.
- **Tertiary Accent (`#E6F7F5` - Soft Teal Tint):** Used strictly for high-readability chip fills, distance pill backdrops, subtle card highlights, and positive validation fields.
- **Neutral Core (`#17212B` Text Primary, `#667085` Text Muted):** Delivers clean contrast without harsh pitch-black extremes. Secondary notes, timestamp metadata, and sub-labels lean strictly on the neutral slate tone.
- **Surfaces & Borders:** Grounded on a crisp cool canvas (`#F6F8FA`), cards float on `#FFFFFF` bordered with precision strokes (`#E2E8F0` / `#E5E9EB`).

## Typography

Typography is set exclusively in Plus Jakarta Sans. Its geometric clarity, wide aperture, and modern curves convey optimism while retaining strict architectural structure.

Letter spacing is intentionally compressed at larger display scales to maintain punchy visual density across storefront banners and profile titles. At metadata, badge, and chip sizes (`11px` to `12px`), uppercase transformations and relaxed trackings ensure legible scanning in dense listing environments.

## Layout & Spacing

This design system uses an 8px base rhythm (`0.5rem` step increments) aligned to a standard 12-column responsive layout.

- **Mobile (Viewport < 768px):** 4 fluid columns, 16px lateral padding, 12px card gutters. Dense, tappable vertical listings with fixed bottom navigation controls and floating action trays.
- **Tablet (Viewport 768px - 1024px):** 8 fluid columns, 24px lateral padding, 16px gutters. Marketplace search split-views and dual-card grid layouts.
- **Desktop (Viewport > 1024px):** 12 columns, max content constraint of 1200px (`75rem`), 24px gutters. Tri-column vendor profiles, persistent map viewports, and multi-step booking drawers.

## Elevation & Depth

Surfaces rely on quiet, multi-stop ambient shadows layered with fine hairline strokes. Heavy drop shadows are strictly avoided to ensure a clean, modern aesthetic.

- **Elevation 0 (Base Flat):** Canvas background `#F6F8FA`. Form backgrounds and inert search inputs sit directly on this plane.
- **Elevation 1 (Card & List Level):** `#FFFFFF` surface with a 1px border `#E2E8F0` and subtle elevation: `0 1px 3px 0 rgba(11, 31, 51, 0.04), 0 1px 2px -1px rgba(11, 31, 51, 0.02)`.
- **Elevation 2 (Interactive Floating & Hover):** Provider cards on active hover, filter chips in active dropdown states: `0 8px 16px -4px rgba(11, 31, 51, 0.08), 0 2px 6px -1px rgba(11, 31, 51, 0.03)`.
- **Elevation 3 (Overlays & Drawers):** Booking confirmation bottom sheets, sticky filters, modal popups: `0 20px 25px -5px rgba(11, 31, 51, 0.12), 0 8px 10px -6px rgba(11, 31, 51, 0.04)`.

## Shapes

The shape hierarchy establishes clear structural zoning across the product:

- **Rounded-2xl (16px / `1rem` base scalar):** Applied universally to primary content modules, vendor profile containers, service option groupings, and interactive search modals.
- **Rounded-xl (12px / `0.75rem`):** Reserved for core inputs, search fields, date-picker selectors, and primary/secondary button containers.
- **Rounded-full (9999px):** Dedicated to dynamic badges, metadata pills, distance tags, verification markers, star badges, and micro-avatars.

## Components

### Buttons
- **Primary:** Solid `#0B1F33` fill, white bold typography, 12px (`rounded-xl`) radius. Height 48px on mobile, 44px on desktop. Active press scales down slightly (`scale-98`).
- **Secondary / Accent:** `#19B6A5` fill with `#0B1F33` or pure white text for direct conversions (e.g., "Book Now").
- **Ghost / Tertiary:** Border 1px `#E2E8F0`, background transparent, text `#17212B`.

### Form Fields & Inputs
- **Base Style:** 48px height, 12px radius, `#FFFFFF` background with 1px `#E5E9EB` stroke. Text set to `#17212B` with `#667085` placeholder values.
- **Focus State:** Stroke transitions cleanly to `#19B6A5` accompanied by a soft teal outer ring blur (`0 0 0 3px rgba(25, 182, 165, 0.15)`).

### Service Chips & Category Selectors
- **Unselected:** Border 1px `#E2E8F0`, text `#17212B`, background `#FFFFFF`. Height 36px, `rounded-full`, 12px lateral padding.
- **Selected:** Background `#0B1F33`, text `#FFFFFF`, border-color `#0B1F33`.

### Specialized Marketplace Indicators & Badges
- **Radius Distance Badge:** Background `#E6F7F5`, text `#19B6A5` (or dark `#0B1F33` for extra contrast), `rounded-full`, uppercase label-sm font with a localized pin glyph (e.g., "1.8 km away"). Highlights proximity inside the 10 km operational zone.
- **Verification Pill:** Background `#0B1F33`, text `#19B6A5`, featuring a miniature geometric diamond icon alongside "Verified Pro".
- **Rating Stars:** Text `#17212B`, icon tint `#F59E0B` (Amber-500) paired with bold numerical rating (`4.9`) and muted review counts in parentheses.
- **Tier Tags (Vendor Categorization):**
  - *T1 Individual:* Neutral slate stroke `#E2E8F0`, dark text `#17212B`.
  - *T2 Team:* Soft teal fill `#E6F7F5`, text `#0B1F33`.
  - *T3 Business:* Deep navy fill `#0B1F33`, text `#FFFFFF`, gold or cyan accent dot.
- **Home Visit Indicator:** Compact badge with house icon, border 1px `#19B6A5`, text `#19B6A5`, background `#FFFFFF`.
- **Cash Change Notice Tag:** Soft warning pill (`#FFFBEB` amber background with `#92400E` border/text) alerting customers and pros to cash change terms upon arrival.

### Cards
- **Vendor Showcase Card:** Outer container 16px radius, 1px `#E2E8F0` border, white background. Contains a 16:9 or 4:3 cover ratio, floating distance badge in the top-right corner, vendor tier pill in the top-left, clean two-line headline, rating row, and fixed-bottom pricing tag.